package com.hexaware.easypay;

import com.hexaware.easypay.controller.EmployeeController;
import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.serviceInterface.IEmployeeService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EmployeeControllerTest {

    @InjectMocks
    private EmployeeController controller;

    @Mock
    private IEmployeeService service;

    @Mock
    private EmployeeRepository employeeRepo;

    private EmployeeDTO mockEmployee;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockEmployee = new EmployeeDTO();
        mockEmployee.setEmpId(1);
        mockEmployee.setEmpName("Alice");
        mockEmployee.setEmail("alice@example.com");
        mockEmployee.setDeptId(101);
        mockEmployee.setDesignation("Developer");
    }

    @Test
    void testAddEmployee() {
        when(service.addEmployee(mockEmployee)).thenReturn("Employee added successfully");
        String result = controller.addEmployee(mockEmployee);
        assertEquals("Employee added successfully", result);
    }

    @Test
    void testGetAllEmployees() {
        when(service.getAllEmployees()).thenReturn(Arrays.asList(mockEmployee));
        List<EmployeeDTO> list = controller.getAllEmployees();
        assertEquals(1, list.size());
        assertEquals("Alice", list.get(0).getEmpName());
    }

    @Test
    void testGetEmployeeById() {
        when(service.getEmployeeById(1)).thenReturn(mockEmployee);
        EmployeeDTO result = controller.getEmployeeById(1);
        assertEquals("Alice", result.getEmpName());
    }

    @Test
    void testUpdateEmployee() {
        when(service.updateEmployee(eq(1), any(EmployeeDTO.class)))
                .thenReturn("Employee updated successfully");
        String result = controller.updateEmployee(1, mockEmployee);
        assertEquals("Employee updated successfully", result);
    }

    @Test
    void testUpdateOwnProfile() {
        when(service.updateOwnProfile(eq(1), any(EmployeeDTO.class)))
                .thenReturn("Profile updated successfully");
        String result = controller.updateOwnProfile(1, mockEmployee);
        assertEquals("Profile updated successfully", result);
    }

    @Test
    void testDeleteEmployee() {
        when(service.deleteEmployee(1)).thenReturn("Employee deleted successfully");
        String result = controller.deleteEmployee(1);
        assertEquals("Employee deleted successfully", result);
    }

    @Test
    void testGetEmployeeCount() {
        when(employeeRepo.count()).thenReturn(5L);
        long count = controller.getEmployeeCount();
        assertEquals(5, count);
    }

    @Test
    void testViewProfileSuccess() {
        Authentication auth = mock(Authentication.class);
        when(auth.isAuthenticated()).thenReturn(true);
        when(auth.getName()).thenReturn("Alice");

        SecurityContextHolder.getContext().setAuthentication(auth);
        when(service.getEmployeeByUsername("Alice")).thenReturn(mockEmployee);

        EmployeeDTO result = controller.viewProfile();
        assertNotNull(result);
        assertEquals("Alice", result.getEmpName());
    }

    @Test
    void testViewProfileNotAuthenticated() {
        SecurityContextHolder.clearContext();

        Exception exception = assertThrows(RuntimeException.class, () -> {
            controller.viewProfile();
        });
        assertEquals("User is not authenticated", exception.getMessage());
    }

    @Test
    void testViewProfileNotFound() {
        Authentication auth = mock(Authentication.class);
        when(auth.isAuthenticated()).thenReturn(true);
        when(auth.getName()).thenReturn("Bob");

        SecurityContextHolder.getContext().setAuthentication(auth);
        when(service.getEmployeeByUsername("Bob")).thenReturn(null);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            controller.viewProfile();
        });
        assertEquals("Employee not found for username: Bob", exception.getMessage());
    }

    @Test
    void testGetEmployeesByDeptAndStatus() {
        List<EmployeeDTO> mockList = Arrays.asList(mockEmployee);
        when(service.getEmployeesByDeptAndStatus(101, "Active")).thenReturn(mockList);

        List<EmployeeDTO> result = controller.getEmployeesByDeptAndStatus(101, "Active");
        assertEquals(1, result.size());
        assertEquals("Alice", result.get(0).getEmpName());
    }
}
