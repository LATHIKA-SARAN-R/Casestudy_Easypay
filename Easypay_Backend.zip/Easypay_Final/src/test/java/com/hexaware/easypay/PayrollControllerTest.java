package com.hexaware.easypay;

import com.hexaware.easypay.controller.PayrollController;
import com.hexaware.easypay.dto.PayrollDTO;
import com.hexaware.easypay.repository.PayrollRepository;
import com.hexaware.easypay.serviceImplementation.PayrollService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PayrollControllerTest {

    @InjectMocks
    private PayrollController controller;

    @Mock
    private PayrollService payrollService;

    @Mock
    private PayrollRepository payrollRepo;

    private PayrollDTO mockPayroll;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockPayroll = new PayrollDTO();
        mockPayroll.setPayrollId(1);
        mockPayroll.setEmpId(101);
        mockPayroll.setBasicSalary(50000);
        mockPayroll.setBonuses(2000);
        mockPayroll.setAllowances(1500);
        mockPayroll.setDeductions(1000);
        mockPayroll.setPayDate(Date.valueOf("2025-07-01"));
        mockPayroll.setNetSalary(52500);
    }

    @Test
    void testAddPayroll() {
        when(payrollService.addPayroll(mockPayroll)).thenReturn(mockPayroll);

        ResponseEntity<PayrollDTO> response = controller.createPayroll(mockPayroll);

        assertEquals(201, response.getStatusCodeValue());
        assertEquals(mockPayroll.getPayrollId(), response.getBody().getPayrollId());
    }

    @Test
    void testGetAllPayrolls() {
        when(payrollService.getAllPayrolls()).thenReturn(Arrays.asList(mockPayroll));

        ResponseEntity<List<PayrollDTO>> response = controller.getAllPayrolls();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals(101, response.getBody().get(0).getEmpId());
    }

    @Test
    void testGetPayrollById() {
        when(payrollService.getPayrollById(1)).thenReturn(mockPayroll);

        ResponseEntity<PayrollDTO> response = controller.getPayrollById(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(50000, response.getBody().getBasicSalary());
    }

    @Test
    void testUpdatePayroll() {
        mockPayroll.setDeductions(1200); // Updated value
        when(payrollService.updatePayroll(1, mockPayroll)).thenReturn(mockPayroll);

        ResponseEntity<PayrollDTO> response = controller.updatePayroll(1, mockPayroll);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1200, response.getBody().getDeductions());
    }

    @Test
    void testDeletePayroll() {
        when(payrollService.deletePayroll(1)).thenReturn("Payroll with ID 1 deleted successfully.");

        ResponseEntity<String> response = controller.deletePayroll(1);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Payroll with ID 1 deleted successfully.", response.getBody());
    }

    @Test
    void testGetPayrollsByEmployeeId() {
        when(payrollService.getPayrollsByEmployeeId(101)).thenReturn(Arrays.asList(mockPayroll));

        ResponseEntity<List<PayrollDTO>> response = controller.getPayrollsByEmployeeId(101);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals(101, response.getBody().get(0).getEmpId());
    }

    @Test
    void testCalculatePayroll() {
        when(payrollService.calculatePayrollForEmployee(101, Date.valueOf("2025-07-01")))
                .thenReturn(mockPayroll);

        ResponseEntity<PayrollDTO> response = controller.calculatePayroll(101, Date.valueOf("2025-07-01"));

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(52500, response.getBody().getNetSalary());
    }

    @Test
    void testGetPayrollCount() {
        when(payrollRepo.count()).thenReturn(10L);

        long result = controller.getPayrollCount();

        assertEquals(10, result);
    }
}
