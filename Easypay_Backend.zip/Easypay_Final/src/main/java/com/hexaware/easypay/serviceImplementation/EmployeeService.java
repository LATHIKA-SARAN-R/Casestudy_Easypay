package com.hexaware.easypay.serviceImplementation;

import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.entity.Department;
import com.hexaware.easypay.entity.Employee;
import com.hexaware.easypay.exception.DepartmentNotFoundException;
import com.hexaware.easypay.exception.ResourceNotFoundException;
import com.hexaware.easypay.mapper.EmployeeMapper;
import com.hexaware.easypay.repository.DepartmentRepository;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.serviceInterface.IEmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService implements IEmployeeService {

    @Autowired
    private EmployeeRepository repository;

    @Autowired
    private EmployeeMapper mapper;

    @Autowired
    private DepartmentRepository departmentrepository;

    @Override
    public String addEmployee(EmployeeDTO dto) {
        Department department = departmentrepository.findById(dto.getDeptId())
                .orElseThrow(() -> new DepartmentNotFoundException("Department not found"));

        Employee employee = mapper.dtoToEmployee(dto);
        employee.setDepartment(department);

        // Save the employee first
        Employee savedEmployee = repository.save(employee);

        // ✅ If designation is Manager, and no manager is currently assigned
        if ("Manager".equalsIgnoreCase(savedEmployee.getDesignation()) && department.getManager() == null) {
            department.setManager(savedEmployee);
            departmentrepository.save(department);
        }

        return "Employee added successfully";
    }


    @Override
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employeeList = repository.findAll();
        List<EmployeeDTO> dtoList = new ArrayList<>();

        for (Employee employee : employeeList) {
            EmployeeDTO dto = mapper.EmployeeToDTO(employee);

            // ✅ Manually set deptId from the department object
            if (employee.getDepartment() != null) {
                dto.setDeptId(employee.getDepartment().getDeptId());
                dto.setDeptName(employee.getDepartment().getDeptName()); // ✅ Add this
            }

            dtoList.add(dto);
        }

        return dtoList;
    }


    @Override
    public EmployeeDTO getEmployeeById(int id) {
        Employee employee = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        return mapper.EmployeeToDTO(employee);
    }

    @Override
    public String updateEmployee(int empId, EmployeeDTO dto) {
        Employee employee = repository.findById(empId)
            .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        Department department = departmentrepository.findById(dto.getDeptId())
            .orElseThrow(() -> new ResourceNotFoundException("Department not found"));

        employee.setEmpName(dto.getEmpName());
        employee.setDesignation(dto.getDesignation());
        employee.setSalary(dto.getSalary());
        employee.setStatus(dto.getStatus());
        employee.setJoiningDate(dto.getJoiningDate());
        employee.setDepartment(department);

        repository.save(employee);

        if ("Manager".equalsIgnoreCase(dto.getDesignation()) && department.getManager() == null) {
            department.setManager(employee);
            departmentrepository.save(department);
        }

        return "Employee updated successfully";
    }

    @Override
    public String updateOwnProfile(int empId, EmployeeDTO dto) {
        Employee employee = repository.findById(empId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        
        employee.setGender(dto.getGender());
        employee.setPhone(dto.getPhone());
        employee.setAddress(dto.getAddress());
        employee.setEmail(dto.getEmail());

        repository.save(employee);
        return "Profile updated successfully";
    }

    @Override
    public String deleteEmployee(int id) {
        Employee employee = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        repository.delete(employee);
        return "Employee deleted successfully";
    }
    
    @Override
    public EmployeeDTO getEmployeeByUsername(String empName) {
        Optional<Employee> optional = repository.findByEmpName(empName);
        return optional.map(mapper::EmployeeToDTO).orElse(null);
    }

    
    @Override
    public List<EmployeeDTO> getEmployeesByDeptAndStatus(int deptId, String status) {
        List<Employee> employees = repository.findByDepartmentDeptIdAndStatus(deptId, status);
        List<EmployeeDTO> dtoList = new ArrayList<>();

        for (Employee employee : employees) {
            EmployeeDTO dto = mapper.EmployeeToDTO(employee);

            if (employee.getDepartment() != null) {
                dto.setDeptId(employee.getDepartment().getDeptId());
                dto.setDeptName(employee.getDepartment().getDeptName());
            }

            dtoList.add(dto);
        }

        return dtoList;
    }

 }
