package com.hexaware.easypay.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.easypay.dto.PayrollDTO;
import com.hexaware.easypay.entity.Payroll;

@Component
public class PayrollMapper
{
        @Autowired
        private ModelMapper modelMapper;

        public Payroll dtoToPayroll(PayrollDTO payrollDTO) 
        {
            return modelMapper.map(payrollDTO, Payroll.class);
        }

        public PayrollDTO PayrollToDto(Payroll entity)
        {
        	PayrollDTO dto = modelMapper.map(entity, PayrollDTO.class);
            dto.setEmpId(entity.getEmployee().getEmpId()); 
            dto.setNetSalary(entity.getNetSalary());
            return dto;
        }
    
}
