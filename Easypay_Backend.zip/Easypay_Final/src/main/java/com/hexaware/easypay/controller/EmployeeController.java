package com.hexaware.easypay.controller;

import com.hexaware.easypay.dto.EmployeeDTO;
import com.hexaware.easypay.repository.EmployeeRepository;
import com.hexaware.easypay.serviceInterface.IEmployeeService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.validation.Valid;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private IEmployeeService service;
    
    @Autowired
    private EmployeeRepository employeeRepo;

    @PostMapping("/addEmployee")
    @PreAuthorize("hasRole('ADMIN')")
    public String addEmployee(@RequestBody @Valid EmployeeDTO dto) {
        return service.addEmployee(dto);
    }

    @GetMapping("/viewAllEmployees")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public List<EmployeeDTO> getAllEmployees() {
        return service.getAllEmployees();
    }

    @GetMapping("/getEmployee/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public EmployeeDTO getEmployeeById(@PathVariable int id) {
        return service.getEmployeeById(id);
    }

    @PutMapping("/updateEmployee/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateEmployee(@PathVariable int id, @RequestBody @Valid EmployeeDTO dto) {
        return service.updateEmployee(id, dto);
    }


    @PutMapping("/updateOwnProfile/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'EMPLOYEE')")
    public String updateOwnProfile(@PathVariable int id, @RequestBody @Valid EmployeeDTO dto) {
        return service.updateOwnProfile(id, dto);
    }

    @DeleteMapping("/removeEmployee/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteEmployee(id);
    }
    
    @GetMapping("/count")
    public long getEmployeeCount() {
        return employeeRepo.count();
    }
    
    @GetMapping("/viewProfile")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER', 'EMPLOYEE')")
    public EmployeeDTO viewProfile() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken) {
            throw new RuntimeException("User is not authenticated");
        }

        String username = auth.getName(); // fetch the logged-in username
        EmployeeDTO dto = service.getEmployeeByUsername(username); // service method must exist

        if (dto == null) {
            throw new RuntimeException("Employee not found for username: " + username);
        }

        return dto; 
        }
    
    @GetMapping("/getEmpByDeptAndStatus/{deptId}/{status}")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public List<EmployeeDTO> getEmployeesByDeptAndStatus(@PathVariable int deptId, @PathVariable String status) {
        return service.getEmployeesByDeptAndStatus(deptId, status);
    }


}