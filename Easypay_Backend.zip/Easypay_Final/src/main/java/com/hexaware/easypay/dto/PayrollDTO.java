package com.hexaware.easypay.dto;

import java.sql.Date;

public class PayrollDTO {

    private int payrollId;
    private double basicSalary;
    private double bonuses = 0;
    private double allowances;
    private double deductions;
    private Date payDate;
    private double netSalary;
    private int empId;

    public PayrollDTO() 
    {
    }

	public PayrollDTO(int payrollId, double basicSalary, double bonuses, double allowances, double deductions,
			Date payDate, double netSalary, int empId) {
		super();
		this.payrollId = payrollId;
		this.basicSalary = basicSalary;
		this.bonuses = bonuses;
		this.allowances = allowances;
		this.deductions = deductions;
		this.payDate = payDate;
		this.netSalary = netSalary;
		this.empId = empId;
	}

	public int getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(int payrollId) {
		this.payrollId = payrollId;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public double getBonuses() {
		return bonuses;
	}

	public void setBonuses(double bonuses) {
		this.bonuses = bonuses;
	}

	public double getAllowances() {
		return allowances;
	}

	public void setAllowances(double allowances) {
		this.allowances = allowances;
	}

	public double getDeductions() {
		return deductions;
	}

	public void setDeductions(double deductions) {
		this.deductions = deductions;
	}

	public Date getPayDate() {
		return payDate;
	}

	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}

	public double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "PayrollDTO [payrollId=" + payrollId + ", basicSalary=" + basicSalary + ", bonuses=" + bonuses
				+ ", allowances=" + allowances + ", deductions=" + deductions + ", payDate=" + payDate + ", netSalary="
				+ netSalary + ", empId=" + empId + "]";
	}
  
    
    
}

   