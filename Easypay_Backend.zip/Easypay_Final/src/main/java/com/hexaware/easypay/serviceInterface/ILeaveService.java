package com.hexaware.easypay.serviceInterface;

import java.util.List;

import com.hexaware.easypay.dto.LeaveDTO;

public interface ILeaveService {
    String requestLeave(LeaveDTO leaveDTO);
    List<LeaveDTO> getMyLeaves(int empId);
    List<LeaveDTO> getTeamLeaves(int managerId);
    String approveLeave(int leaveId);
    String rejectLeave(int leaveId);
    List<LeaveDTO> getLeavesByDepartmentAndActiveEmployees(int deptId);
}
