package com.hexaware.easypay.serviceInterface;

import java.sql.Date;
import java.util.List;

import com.hexaware.easypay.dto.PayrollDTO;


public interface IPayrollService 
{

    PayrollDTO addPayroll(PayrollDTO payroll);
    PayrollDTO getPayrollById(int id);
    List<PayrollDTO> getAllPayrolls();
    PayrollDTO updatePayroll(int id,  PayrollDTO dto);
    String deletePayroll(int id);
    List<PayrollDTO> getPayrollsByEmployeeId(int employeeId);
    PayrollDTO calculatePayrollForEmployee(int empId, Date payDate);

}
