package com.hexaware.easypay.repository;

import com.hexaware.easypay.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<Users, Integer> 
{
	
    Optional<Users> findByUsernameIgnoreCase(String username);

}