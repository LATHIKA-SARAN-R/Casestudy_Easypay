package com.hexaware.easypay.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.easypay.entity.Leaves;

import java.util.List;

public interface LeaveRepository extends JpaRepository<Leaves, Integer> {
    List<Leaves> findByEmployeeEmpId(int empId);
    List<Leaves> findByEmployee_Department_DeptIdAndEmployee_Status(int deptId, String status);
    List<Leaves> findByEmployeeDepartmentDeptIdAndEmployeeStatus(int deptId, String status);



}
