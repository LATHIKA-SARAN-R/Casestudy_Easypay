package com.hexaware.easypay.entity;

import com.hexaware.easypay.enumeration.UserRole;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
public class Users {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank
    @Size(min = 3, max = 20)
    private String username;

    @NotBlank
    @Size(min = 6)
    private String password;

    @Enumerated(EnumType.STRING)
    private UserRole role;

    public Users() {}

    public Users(int id, String username, String password, UserRole role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public int getId() 
    {
    	return id;
    }
    
    public void setId(int id) 
    {
    	this.id = id; 
    }
    
    public String getUsername() 
    {
    	return username;
    }
    
    public void setUsername(String username) 
    {
    	this.username = username; 
    }
    
    public String getPassword() 
    {
    	return password; 
    }
    
    public void setPassword(String password) 
    {
    	this.password = password;
   	}
    
    public UserRole getRole()
    { 
    	return role; 
    }
    
    public void setRole(UserRole role)
    {
    	this.role = role;
    }
    
}