import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import { Home } from './pages/Home';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import TermsAndCondition from './components/TermsAndCondition';
import About from './components/About';
import Contact from './components/Contact';

import AdminDashboard from './Admin/AdminDashboard';
import ManagerDashboard from './Manager/ManagerDashboard';

import EmployeeManagement from './Admin/EmployeeManagement';
import LeaveManagement from './Admin/LeaveManagement';
import DepartmentManagement from './Admin/DepartmentManagement';
import PayrollManagement from './Admin/PayrollManagement';

import EmployeeManager from './Manager/Employee_manager';
import PayrollManager from './Manager/PayrollManager';
import LeaveManager from './Manager/LeaveManager';
import ManagerProfile from './Manager/ManagerProfile';

import Dashboard from './Employee/Dashboard';
import ShowPayroll from './Employee/ShowPayroll';
import LeaveRequest from './Employee/LeaveRequest';
import PersonalInfo from './Employee/PersonalInfo';


const App = () => {
  return (
    
      <Routes>
        {/* General */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/terms-of-service" element={<TermsAndCondition />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />

        {/* Admin */}
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/employees" element={<EmployeeManagement />} />
        <Route path="/admin/leaves" element={<LeaveManagement />} />
        <Route path="/admin/dept" element={<DepartmentManagement />} />
        <Route path="/admin/payroll" element={<PayrollManagement />} />

        {/* Manager */}
        <Route path="/manager" element={<ManagerDashboard />} />
        <Route path="/manager/employee" element={<EmployeeManager />} />
        <Route path="/manager/payroll" element={<PayrollManager />} />
        <Route path="/manager/leaves" element={<LeaveManager />} />
        <Route path="/manager/profile" element={<ManagerProfile />} />

        <Route path="/employee" element={<Dashboard />} />
        <Route path="/employee/payroll" element={<ShowPayroll />} />
        <Route path="/employee/leave" element={<LeaveRequest />} />
        <Route path="/employee/info" element={<PersonalInfo />} />

      </Routes>
   
  );
};

export default App;
