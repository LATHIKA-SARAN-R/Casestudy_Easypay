import { configureStore } from '@reduxjs/toolkit';
import managerStatsReducer from './managerStatsSlice';
import adminStatsReducer from './adminStatsSlice';

export const store = configureStore({
  reducer: {
    managerStats: managerStatsReducer,
    adminStats: adminStatsReducer,
  },
});
