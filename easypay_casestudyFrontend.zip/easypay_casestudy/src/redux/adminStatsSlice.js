import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const token = localStorage.getItem('token');

export const fetchAdminStats = createAsyncThunk('adminStats/fetch', async () => {
  const [empRes, deptRes, payrollRes] = await Promise.all([
    axios.get('http://localhost:9000/employee/count', {
      headers: { Authorization: `Bearer ${token}` },
    }),
    axios.get('http://localhost:9000/departments/count', {
      headers: { Authorization: `Bearer ${token}` },
    }),
    axios.get('http://localhost:9000/payroll/count', {
      headers: { Authorization: `Bearer ${token}` },
    }),
  ]);

  return {
    totalEmployees: empRes.data,
    totalDepartments: deptRes.data,
    totalPayrolls: payrollRes.data,
  };
});

const adminStatsSlice = createSlice({
  name: 'adminStats',
  initialState: {
    totalEmployees: 0,
    totalDepartments: 0,
    totalPayrolls: 0,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchAdminStats.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAdminStats.fulfilled, (state, action) => {
        state.loading = false;
        state.totalEmployees = action.payload.totalEmployees;
        state.totalDepartments = action.payload.totalDepartments;
        state.totalPayrolls = action.payload.totalPayrolls;
      })
      .addCase(fetchAdminStats.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export default adminStatsSlice.reducer;
