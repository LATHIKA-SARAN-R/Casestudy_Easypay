import React, { useEffect, useState } from "react";
import axios from "axios";

const PersonalInfo = () => {
  const [user, setUser] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    phone: "",
    address: "",
    gender: "",
  });
  const [successMsg, setSuccessMsg] = useState("");
  const [profilePic, setProfilePic] = useState(localStorage.getItem("profilePic"));

  useEffect(() => {
    const fetchUser = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        alert("User is not authenticated.");
        window.location.href = "/login";
        return;
      }

      try {
        const res = await axios.get("http://localhost:9000/employee/viewProfile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(res.data);
        setFormData({
          email: res.data.email || "",
          phone: res.data.phone || "",
          address: res.data.address || "",
          gender: res.data.gender || "",
        });
      } catch (error) {
        alert("Failed to fetch user profile.");
        console.error(error);
      }
    };

    fetchUser();
  }, []);

  const handleUpdate = async () => {
    try {
      await axios.put(
        `http://localhost:9000/employee/updateOwnProfile/${user.empId}`,
        formData,
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      setSuccessMsg("✅ Profile updated successfully!");
      setTimeout(() => {
        setShowModal(false);
        window.location.reload();
      }, 1500);
    } catch (error) {
      alert("Failed to update profile.");
      console.error(error);
    }
  };

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePic(reader.result);
        localStorage.setItem("profilePic", reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Banner */}
      <div
        className="h-40 bg-cover bg-center relative"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1350&q=80')",
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40" />
        <div className="absolute inset-x-0 bottom-[-4rem] flex justify-center z-20 relative">
          <div className="relative group">
            <img
              className="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover"
              src={
                profilePic ||
                "https://wallpapers.com/images/hd/discord-profile-pictures-xk3qyllfj1j46kte.jpg"
              }
              alt="Profile"
            />
            {/* Edit Icon Overlay */}
            <label className="absolute bottom-1 right-1 bg-white rounded-full p-1 shadow cursor-pointer hover:bg-gray-100 transition">
              <input
                type="file"
                accept="image/*"
                onChange={handleProfilePicChange}
                className="hidden"
              />
              <svg
                className="w-5 h-5 text-gray-600"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M5 20h14v-2H5v2zm14.7-13.3l-2.4-2.4a1 1 0 00-1.4 0L8 12.6V15h2.4l7.9-7.9a1 1 0 000-1.4z" />
              </svg>
            </label>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 md:p-10 mt-16">
        <div className="bg-white shadow-xl rounded-2xl p-6 md:p-10 relative">
          {user ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Personal Information</h2>
                <button
                  onClick={() => setShowModal(true)}
                  className="bg-white text-indigo-600 border border-indigo-600 px-4 py-1 rounded-lg shadow hover:bg-indigo-600 hover:text-white transition"
                >
                  Edit Profile
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
                <InfoField label="Employee ID" value={user.empId} />
                <InfoField label="Gender" value={user.gender} />
                <InfoField label="Employee Name" value={user.empName} />
                <InfoField label="Email" value={user.email} />
                <InfoField label="Phone Number" value={user.phone} />
                <InfoField label="Address" value={user.address} />
              </div>

              <h2 className="text-2xl font-bold text-gray-800 mt-10 mb-2">Department Information</h2>
              <hr className="mb-6" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InfoField label="Job Title" value={user.designation} />
                <InfoField label="Department ID" value={user.deptId} />
                <InfoField label="Basic Salary" value={user.salary ? `₹${user.salary}` : ""} />
                <InfoField label="Joining Date" value={user.joiningDate} />
                <InfoField label="Status" value={user.status} />
              </div>
            </>
          ) : (
            <p className="text-center text-gray-500">Loading profile...</p>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-40 z-50">
          <div className="bg-white p-8 rounded-lg w-full max-w-lg shadow-lg">
            <h3 className="text-xl font-bold text-gray-800 mb-6 text-center">Edit Profile</h3>

            {successMsg && (
              <div className="bg-green-100 text-green-800 px-4 py-2 rounded mb-4 text-center">
                {successMsg}
              </div>
            )}

            <div className="space-y-4">
              <InputField label="Email" name="email" value={formData.email} onChange={handleChange} />
              <InputField label="Phone" name="phone" value={formData.phone} onChange={handleChange} />
              <TextAreaField label="Address" name="address" value={formData.address} onChange={handleChange} />
              <SelectField
                label="Gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                options={["Male", "Female", "Other"]}
              />
            </div>

            <div className="mt-6 flex justify-center gap-4">
              <button
                onClick={handleUpdate}
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg"
              >
                Save
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Reusable Fields
const InfoField = ({ label, value }) => (
  <div>
    <label className="text-gray-700 font-medium">{label}</label>
    <input
      type="text"
      value={value || ""}
      readOnly
      className="mt-1 block w-full rounded-md bg-gray-100 border border-gray-200 p-2 text-gray-800"
    />
  </div>
);

const InputField = ({ label, name, value, onChange }) => (
  <div>
    <label className="text-gray-700 font-medium">{label}</label>
    <input
      type="text"
      name={name}
      value={value}
      onChange={onChange}
      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
    />
  </div>
);

const TextAreaField = ({ label, name, value, onChange }) => (
  <div>
    <label className="text-gray-700 font-medium">{label}</label>
    <textarea
      name={name}
      rows={3}
      value={value}
      onChange={onChange}
      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
    />
  </div>
);

const SelectField = ({ label, name, value, onChange, options }) => (
  <div>
    <label className="text-gray-700 font-medium">{label}</label>
    <select
      name={name}
      value={value}
      onChange={onChange}
      className="mt-1 block w-full rounded-md border border-gray-300 p-2"
    >
      <option value="">-- Select Gender --</option>
      {options.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  </div>
);

export default PersonalInfo;
