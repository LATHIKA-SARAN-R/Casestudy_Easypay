import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import EmployeeSidebar from "./EmployeeSidebar";

export default function LeaveDashboard() {
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    leaveType: "",
    startDate: "",
    endDate: "",
  });
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  const fetchProfile = async () => {
    if (!token) return null;
    try {
      const res = await axios.get("http://localhost:9000/employee/viewProfile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      return res.data;
    } catch (err) {
      console.error("Error fetching profile:", err);
      return null;
    }
  };

  const fetchLeaves = async (empId) => {
    try {
      const res = await axios.get(`http://localhost:9000/leave/myLeaves/${empId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaveRequests(res.data);
    } catch (err) {
      console.error("Error fetching leaves:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const initialize = async () => {
      const profile = await fetchProfile();
      if (profile?.empId) {
        await fetchLeaves(profile.empId);
      } else {
        alert("Employee ID not found.");
        setLoading(false);
      }
    };
    initialize();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const profile = await fetchProfile();
    if (!profile?.empId) {
      alert("Employee ID not found.");
      return;
    }

    const newLeave = { ...formData, empId: profile.empId };

    try {
      await axios.post("http://localhost:9000/leave/requestLeave", newLeave, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await fetchLeaves(profile.empId);
      setFormData({ leaveType: "", startDate: "", endDate: "" });
      setIsOpen(false);
    } catch (error) {
      console.error("Error submitting leave:", error.response || error.message);
      alert("Failed to submit leave. Please try again.");
    }
  };

  return (
    <div className="flex flex-col h-screen">
      <Navbar user={true} />

      <div className="flex flex-1 overflow-hidden">
        <EmployeeSidebar />

        <div className="flex-1 overflow-y-auto bg-gray-100 p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800">Leave Requests</h1>
            <button
              onClick={() => setIsOpen(true)}
              className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
            >
              + Apply Leave
            </button>
          </div>

          {loading ? (
            <p className="text-gray-600 text-center">Loading leave requests...</p>
          ) : leaveRequests.length === 0 ? (
            <p className="text-gray-600 text-center">No leave requests yet.</p>
          ) : (
            <div className="overflow-x-auto bg-white shadow rounded-xl">
              <table className="min-w-full text-sm text-left">
                <thead>
                  <tr className="bg-indigo-100 text-gray-700 uppercase text-xs tracking-wider">
                    <th className="py-3 px-4">Leave Type</th>
                    <th className="py-3 px-4">Start Date</th>
                    <th className="py-3 px-4">End Date</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {leaveRequests.map((leave, index) => (
                    <tr key={leave.leaveId || index} className="border-b hover:bg-gray-50 transition">
                      <td className="py-3 px-4">{leave.leaveType}</td>
                      <td className="py-3 px-4">{leave.startDate}</td>
                      <td className="py-3 px-4">{leave.endDate}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-1 text-xs font-medium rounded-full ${
                            leave.status === "Approved"
                              ? "bg-green-100 text-green-700"
                              : leave.status === "Pending"
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-red-100 text-red-700"
                          }`}
                        >
                          {leave.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Leave Application Modal */}
          {isOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md relative">
                <h2 className="text-xl font-bold text-center mb-4">Leave Application</h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="absolute top-2 right-3 text-xl font-bold text-gray-500 hover:text-gray-700"
                >
                  &times;
                </button>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block mb-1 text-sm font-medium">Leave Type</label>
                    <select
                      name="leaveType"
                      value={formData.leaveType}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-md p-2"
                      required
                    >
                      <option value="">Select Type</option>
                      <option value="SICK">Sick</option>
                      <option value="CASUAL">Casual</option>
                      <option value="EARNED">Earned</option>
                    </select>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex-1">
                      <label className="block mb-1 text-sm font-medium">Start Date</label>
                      <input
                        type="date"
                        name="startDate"
                        value={formData.startDate}
                        onChange={handleChange}
                        className="w-full border border-gray-300 rounded-md p-2"
                        required
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block mb-1 text-sm font-medium">End Date</label>
                      <input
                        type="date"
                        name="endDate"
                        value={formData.endDate}
                        onChange={handleChange}
                        className="w-full border border-gray-300 rounded-md p-2"
                        required
                      />
                    </div>
                  </div>

                  <div className="text-right">
                    <button
                      type="submit"
                      className="mt-2 px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-md"
                    >
                      Submit Request
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
