import { useState,useEffect } from "react";
import { Link } from "react-router-dom";

const HeroSection = () => {
const images = [
  'https://tse1.mm.bing.net/th/id/OIP.fc3IPPiJbKzagufqJ0sAeAHaEc?pid=ImgDet&w=178&h=106&c=7&dpr=1.5&o=7&rm=3',
  'https://tse3.mm.bing.net/th/id/OIP.joMhBLjoEwq5U7cwVU7yqwHaFo?rs=1&pid=ImgDetMain&o=7&rm=3',
  'https://static.vecteezy.com/system/resources/thumbnails/007/389/558/small_2x/asian-group-of-company-coworkers-at-the-office-discuss-about-business-strategy-of-new-investments-free-photo.JPG',
];
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % images.length);
    }, 4000); // 4 second changes 
    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <div>
      <main className="bg-white text-gray-800">
        <div className="relative w-full h-screen overflow-hidden">
      {images.map((src, index) => (
        <div
          key={index}
          className={`absolute top-0 left-0 w-full h-full transition-opacity duration-1000 ease-in-out ${
            index === current ? 'opacity-100 z-10' : 'opacity-0 z-0'
          }`}
        >
          <img
            src={src}
            alt={`Slide ${index + 1}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex flex-col items-center justify-center text-white px-4">
            <h1 className="text-4xl lg:text-6xl font-bold mb-4 text-center">Welcome to Our Platform</h1>
            <p className="text-lg lg:text-2xl max-w-xl text-center mb-6">
              Empowering your business with innovative solutions tailored for growth.
            </p>
            <Link to='/login' className="bg-indigo-500 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-lg transition duration-300">
              Get Started
            </Link>
          </div>
        </div>
      ))}
    </div>
        <section className="py-12 text-center">
          <h1 className="text-4xl font-bold mb-4">Our Services</h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">
            <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
              <img
                src="https://cdn-icons-png.flaticon.com/512/4285/4285453.png"
                alt="Manage Payroll"
                className="w-20 mx-auto mb-4"
              />
              <h2 className="text-xl font-semibold mb-2">Manage Payroll</h2>
              <p className="text-gray-600">
                Streamline payroll management with real-time data for accurate,
                efficient processing. Customize options to meet your
                organization’s unique payroll needs effortlessly.
              </p>
            </div>
            {/* Card 2 */}
            <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
              <img
                src="https://cdn-icons-png.flaticon.com/512/2920/2920253.png"
                alt="Generate Reports"
                className="w-20 mx-auto mb-4"
              />
              <h2 className="text-xl font-semibold mb-2">Generate Reports</h2>
              <p className="text-gray-600">
                Generate comprehensive reports to uncover valuable insights into
                payroll trends, employee compensation patterns, and financial
                statistics.
              </p>
            </div>
            {/* Card 3 */}
            <div className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition">
              <img
                src="https://cdn-icons-png.flaticon.com/512/4108/4108930.png"
                alt="System Features"
                className="w-20 mx-auto mb-4"
              />
              <h2 className="text-xl font-semibold mb-2">System Features</h2>
              <p className="text-gray-600">
                Explore the complete suite of features that set Easypay apart as
                a top payroll solution, from seamless automation to robust
                compliance tools.
              </p>
            </div>
          </div>
        </section>

        {/* Meet Easypay */}
        <section className="bg-blue-50 py-12">
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Meet Easypay</h2>
              <p className="text-gray-700 leading-relaxed">
               At EasyPay, we do more than just handle numbers — we’re redefining how payroll works. Our goal is to eliminate the complexity of payroll processing and replace it with a smooth, intuitive experience that’s simple for everyone to use.

Forget the confusion of traditional payroll systems — EasyPay brings clarity and confidence to the process. We ensure your team is paid accurately and on time, every time, without the hassle.

Say goodbye to manual spreadsheets and repetitive calculations. With EasyPay’s intelligent and user-friendly interface, managing payroll becomes fast, easy, and stress-free — even for those with little to no technical background.
              </p>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1593642532973-d31b6557fa68"
                alt="Office"
                className="rounded-lg shadow"
              />
            </div>
          </div>
        </section>
 <footer className="bg-gray-800 text-gray-200 py-6">
      <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
        <p className="text-sm mb-2 md:mb-0">
          © {new Date().getFullYear()} EasyPay. All rights reserved.
        </p>
        <div className="flex space-x-4">
          <a
            href="/about"
            className="hover:text-white transition-colors text-sm"
          >
            Privacy Policy
          </a>
          <a
            href="/terms-of-service"
            className="hover:text-white transition-colors text-sm"
          >
            Terms of Service
          </a>
          <a
            href="/contact"
            className="hover:text-white transition-colors text-sm"
          >
            Contact Us
          </a>
        </div>
      </div>
    </footer>

      </main>
    </div>
  );
};

export default HeroSection;
