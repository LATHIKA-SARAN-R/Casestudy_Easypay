
import React from 'react'

const TermsAndCondition = () => {
  return (
    <h2>
    Terms and Conditions
    </h2>
  )
}
export default TermsAndCondition;