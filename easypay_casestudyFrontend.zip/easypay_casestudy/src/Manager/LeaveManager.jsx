import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const LeaveManager = () => {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch {
      return null;
    }
  };

  const fetchLeaves = async (managerEmpId) => {
    try {
      const response = await axios.get(`http://localhost:9000/leave/teamLeaves/${managerEmpId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves(response.data);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const getManagerEmpId = async () => {
    const username = parseJwt(token)?.sub;
    if (!username) return setLoading(false);

    try {
      const res = await axios.get('http://localhost:9000/employee/viewAllEmployees', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const emp = res.data.find(e => e.empName.toLowerCase() === username.toLowerCase());
      if (emp) fetchLeaves(emp.empId);
    } catch (err) {
      console.error('Error fetching manager ID:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (leaveId, action) => {
    try {
      await axios.put(`http://localhost:9000/leave/${action}Leave/${leaveId}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setLeaves(prev =>
        prev.map(l =>
          l.leaveId === leaveId ? { ...l, status: action === 'approve' ? 'APPROVED' : 'REJECTED' } : l
        )
      );
    } catch (err) {
      console.error(`Error on ${action}:`, err);
    }
  };

  useEffect(() => {
    getManagerEmpId();
  }, []);

  const statusBadge = (status) => {
    const base = "px-2 py-1 text-xs rounded-full font-semibold";
    if (status === 'PENDING') return <span className={`${base} bg-yellow-100 text-yellow-800`}>Pending</span>;
    if (status === 'APPROVED') return <span className={`${base} bg-green-100 text-green-800`}>Approved</span>;
    return <span className={`${base} bg-red-100 text-red-800`}>Rejected</span>;
  };

  const renderTable = (title, data, showActions = false) => (
    <div className="mb-10">
      <h3 className="text-xl font-semibold text-gray-800 mb-4">{title}</h3>
      <div className="overflow-x-auto bg-white shadow-md rounded-xl">
        <table className="min-w-full text-sm text-left">
          <thead className="bg-teal-600 text-white uppercase text-xs tracking-wider">
            <tr>
              <th className="px-5 py-3">Leave ID</th>
              <th className="px-5 py-3">Employee Name</th>
              <th className="px-5 py-3">Start Date</th>
              <th className="px-5 py-3">End Date</th>
              <th className="px-5 py-3">Status</th>
              {showActions && <th className="px-5 py-3">Actions</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {data.length === 0 ? (
              <tr>
                <td colSpan={showActions ? 6 : 5} className="text-center py-5 text-gray-400">
                  No records available
                </td>
              </tr>
            ) : (
              data.map((leave) => (
                <tr key={leave.leaveId} className="hover:bg-gray-50">
                  <td className="px-5 py-3 font-mono">{leave.leaveId}</td>
                  <td className="px-5 py-3">{leave.employee?.empName}</td>
                  <td className="px-5 py-3">{leave.startDate}</td>
                  <td className="px-5 py-3">{leave.endDate}</td>
                  <td className="px-5 py-3">{statusBadge(leave.status)}</td>
                  {showActions && (
                    <td className="px-5 py-3 space-x-2">
                      <button
                        onClick={() => handleAction(leave.leaveId, 'approve')}
                        className="bg-green-600 hover:bg-green-700 text-white text-xs px-3 py-1 rounded-md"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleAction(leave.leaveId, 'reject')}
                        className="bg-red-600 hover:bg-red-700 text-white text-xs px-3 py-1 rounded-md"
                      >
                        Reject
                      </button>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  const pending = leaves.filter(l => l.status === 'PENDING');
  const approved = leaves.filter(l => l.status === 'APPROVED');
  const rejected = leaves.filter(l => l.status === 'REJECTED');

  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1 overflow-hidden">
        <ManagerSidebar />
        <div className="flex-1 overflow-y-auto bg-gray-50 p-8">
          <div className="mb-10 text-center">
            <h2 className="text-3xl font-bold text-gray-900">Manage Leave Requests</h2>
            <p className="text-gray-500 mt-1 text-sm">
              Review and respond to team leave applications efficiently.
            </p>
          </div>

          {loading ? (
            <div className="text-center text-gray-500">Loading leave requests...</div>
          ) : (
            <>
              {renderTable('Pending Leave Requests', pending, true)}
              {renderTable('Approved Leave Requests', approved)}
              {renderTable('Rejected Leave Requests', rejected)}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaveManager;
