import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import ManagerSidebar from './ManagerSidebar';

const PayrollManager = () => {
  const [payrolls, setPayrolls] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split('.')[1]));
    } catch (e) {
      return null;
    }
  };

  const getManagerDepartmentId = async (username) => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const dept = res.data.find(d => d.managerName === username);
      return dept ? dept.deptId : null;
    } catch (err) {
      console.error('Error fetching departments:', err);
      return null;
    }
  };

  const fetchData = async (deptId) => {
    try {
      const [empRes, payrollRes] = await Promise.all([
        axios.get('http://localhost:9000/employee/viewAllEmployees', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get('http://localhost:9000/payroll/viewAllPayroll', {
          headers: { Authorization: `Bearer ${token}` }
        }),
      ]);

      const deptEmployees = empRes.data.filter(emp =>
        emp.deptId === deptId && emp.designation.toLowerCase() !== 'manager'
      );

      const empIds = deptEmployees.map(emp => emp.empId);
      const filteredPayrolls = payrollRes.data.filter(p => empIds.includes(p.empId));
      setPayrolls(filteredPayrolls);
    } catch (err) {
      console.error('Error fetching payrolls/employees:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const tokenData = parseJwt(token);
    const username = tokenData?.sub;

    if (username) {
      getManagerDepartmentId(username).then(deptId => {
        if (deptId) fetchData(deptId);
        else setLoading(false);
      });
    } else {
      console.error('Invalid token');
      setLoading(false);
    }
  }, []);

  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1 overflow-hidden">
        <ManagerSidebar />
        <div className="flex-1 overflow-y-auto p-8 bg-gray-50">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Department Payrolls</h2>

          {loading ? (
            <div className="text-center text-gray-500">Loading payroll data...</div>
          ) : payrolls.length === 0 ? (
            <div className="text-center text-red-500">No payroll data available for your department.</div>
          ) : (
            <div className="bg-white shadow-md rounded-xl overflow-x-auto border border-gray-200">
              <table className="min-w-full text-sm divide-y divide-gray-100">
                <thead className="bg-gray-100 text-gray-700 text-left">
                  <tr>
                    <th className="px-6 py-3 font-medium">Payroll ID</th>
                    <th className="px-6 py-3 font-medium">Employee ID</th>
                    <th className="px-6 py-3 font-medium">Pay Date</th>
                    <th className="px-6 py-3 font-medium">Basic Salary</th>
                    <th className="px-6 py-3 font-medium">Bonuses</th>
                    <th className="px-6 py-3 font-medium">Allowances</th>
                    <th className="px-6 py-3 font-medium">Deductions</th>
                    <th className="px-6 py-3 font-medium">Net Salary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {payrolls.map((pay) => (
                    <tr key={pay.payrollId} className="hover:bg-gray-50 transition">
                      <td className="px-6 py-3">{pay.payrollId}</td>
                      <td className="px-6 py-3">{pay.empId}</td>
                      <td className="px-6 py-3">{pay.payDate}</td>
                      <td className="px-6 py-3">₹{pay.basicSalary}</td>
                      <td className="px-6 py-3">₹{pay.bonuses}</td>
                      <td className="px-6 py-3">₹{pay.allowances}</td>
                      <td className="px-6 py-3">₹{pay.deductions}</td>
                      <td className="px-6 py-3 font-semibold text-green-600">₹{pay.netSalary}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PayrollManager;
