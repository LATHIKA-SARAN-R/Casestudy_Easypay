import React, { useState } from 'react'
import {Link} from 'react-router-dom'
import {Bars3Icon, CalendarDaysIcon, HomeIcon, WalletIcon } from '@heroicons/react/24/solid';
import { UserCircleIcon } from '@heroicons/react/16/solid';

const ManagerSidebar = () => {
     const [collapsed , setCollapsed] = useState(false);
  return (
     <div className={` h-screen p-4 shadow-md transition-all rounded-lg duration-300 ${collapsed ? 'w-15' : 'w-60'}`}>
      <button
        className="text-gray-600 mb-6"
        onClick={() => setCollapsed(!collapsed)}
      >
     <Bars3Icon className='h-5 w-5' />
      </button>
      <div className="border-t border-gray-300 mb-4"></div>

      <ul className="space-y-6">
        <li>
          <Link to="/manager" className="flex items-center space-x-2 hover:text-blue-600">
            <HomeIcon className='h-5 w-5' />
            {!collapsed && <span>Dashboard</span>}
          </Link>
        </li>

        <li>
                  <Link to="/manager/employee" className="flex items-center space-x-2 hover:text-blue-600">
          <UserCircleIcon className='h-5 w-5' />
          {!collapsed && <span>Employees</span>}
        </Link>
                </li>

        <li>
          <Link to="/manager/payroll" className="flex items-center space-x-2 hover:text-blue-600">
           <WalletIcon className='h-5 w-5' />
            {!collapsed && <span>PayRoll</span>}
          </Link>
        </li>
        <li>
          <Link to="/manager/leaves" className="flex items-center space-x-2 hover:text-blue-600">
            <CalendarDaysIcon className='h-5 w-5'/>
            {!collapsed && <span>Leave Request</span>}
          </Link>
        </li>
        <li>
          <Link to="/manager/profile" className="flex items-center space-x-2 hover:text-blue-600">
            <UserCircleIcon className='h-5 w-5' />
            {!collapsed && <span>Profile</span>}
          </Link>
        </li>
        
       
      </ul>
    </div>
  )
}

export default ManagerSidebar