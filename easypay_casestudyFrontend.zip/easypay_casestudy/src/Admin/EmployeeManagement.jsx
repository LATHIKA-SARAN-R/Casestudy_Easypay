import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedTab, setSelectedTab] = useState('Active');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDeptId, setFilterDeptId] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingEmp, setEditingEmp] = useState(null);
  const [formData, setFormData] = useState({
    empName: '', email: '', phone: '', address: '',
    designation: '', gender: '', status: '',
    joiningDate: '', salary: '', deptId: ''
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
  }, []);

  const fetchEmployees = async () => {
    try {
      const res = await axios.get('http://localhost:9000/employee/viewAllEmployees', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEmployees(res.data);
    } catch (err) {
      console.error('Error fetching employees:', err);
    }
  };

  const fetchDepartments = async () => {
    try {
      const res = await axios.get('http://localhost:9000/departments/showAllDepartments', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setDepartments(res.data);
    } catch (err) {
      console.error('Error fetching departments:', err);
    }
  };

  const filteredEmployees = employees
    .filter(emp => emp.status === selectedTab)
    .filter(emp => emp.empName.toLowerCase().includes(searchQuery.toLowerCase()))
    .filter(emp => (filterDeptId ? emp.deptId === parseInt(filterDeptId) : true));

  const startEdit = (emp) => {
    setEditingEmp(emp);
    setShowModal(true);
    setFormData({
      empId: emp.empId,
      empName: emp.empName,
      email: emp.email,
      phone: emp.phone,
      address: emp.address,
      designation: emp.designation,
      gender: emp.gender,
      status: emp.status,
      joiningDate: emp.joiningDate,
      salary: emp.salary,
      deptId: emp.deptId?.toString() || '',
    });
  };

  const openAddModal = () => {
    setEditingEmp(null);
    setShowModal(true);
    setFormData({
      empName: '', email: '', phone: '', address: '',
      designation: '', gender: '', status: '',
      joiningDate: '', salary: '', deptId: ''
    });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCancel = () => {
    setShowModal(false);
    setEditingEmp(null);
  };

  const submitForm = async () => {
    try {
      const payload = {
        empName: formData.empName,
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
        designation: formData.designation,
        gender: formData.gender,
        status: formData.status,
        joiningDate: formData.joiningDate,
        salary: formData.salary,
        deptId: parseInt(formData.deptId),
      };

      if (editingEmp) {
        await axios.put(`http://localhost:9000/employee/updateEmployee/${formData.empId}`, payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert('Employee updated successfully');
      } else {
        await axios.post('http://localhost:9000/employee/addEmployee', payload, {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert('Employee added successfully');
      }

      setShowModal(false);
      fetchEmployees();
    } catch (err) {
      console.error('Submit failed:', err.response?.data || err.message);
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 bg-gray-50 p-6 overflow-y-auto">
          <div className="bg-white shadow-md rounded-lg p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Employee Management</h2>
              <button
                onClick={openAddModal}
                className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-md"
              >
                + Add Employee
              </button>
            </div>

            <div className="flex gap-4 mb-4 flex-wrap">
              <input
                type="text"
                placeholder="Search by name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded w-full max-w-xs"
              />
              <select
                value={filterDeptId}
                onChange={(e) => setFilterDeptId(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded w-full max-w-xs"
              >
                <option value="">All Departments</option>
                {departments.map(dept => (
                  <option key={dept.deptId} value={dept.deptId}>
                    {dept.deptName}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex border-b mb-4">
              {['Active', 'Inactive'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setSelectedTab(tab)}
                  className={`px-4 py-2 font-semibold ${selectedTab === tab
                    ? 'border-b-4 border-green-600 text-green-700'
                    : 'text-gray-500 hover:text-green-600'
                    }`}
                >
                  {tab} Employees
                </button>
              ))}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm border border-gray-300 rounded-md">
                <thead className="bg-gray-200 text-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left">ID</th>
                    <th className="px-4 py-2 text-left">Name</th>
                    <th className="px-4 py-2 text-left">Email</th>
                    <th className="px-4 py-2 text-left">Designation</th>
                    <th className="px-4 py-2 text-left">Department</th>
                    <th className="px-4 py-2 text-left">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEmployees.map((emp, idx) => (
                    <tr key={emp.empId} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="px-4 py-2">{emp.empId}</td>
                      <td className="px-4 py-2">{emp.empName}</td>
                      <td className="px-4 py-2">{emp.email}</td>
                      <td className="px-4 py-2">{emp.designation}</td>
                      <td className="px-4 py-2">
                        {departments.find((d) => d.deptId === emp.deptId)?.deptName || 'N/A'}
                      </td>
                      <td className="px-4 py-2">
                        <button
                          onClick={() => startEdit(emp)}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded-md"
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {showModal && (
            <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-40">
              <div className="bg-white rounded-lg p-6 w-full max-w-2xl shadow-xl mx-4 overflow-y-auto max-h-[90vh]">
                <h2 className="text-xl font-bold mb-4 text-gray-800">
                  {editingEmp ? 'Edit Employee Details' : 'Add New Employee'}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { label: 'EmpName', name: 'empName' },
                    { label: 'Email', name: 'email', disabled: editingEmp },
                    { label: 'Phone', name: 'phone', disabled: editingEmp },
                    { label: 'Address', name: 'address', disabled: editingEmp },
                    { label: 'Designation', name: 'designation' },
                    { label: 'Salary', name: 'salary' }
                  ].map(({ label, name, disabled }) => (
                    <div key={name}>
                      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                      <input
                        name={name}
                        type={name === 'salary' ? 'number' : 'text'}
                        value={formData[name]}
                        onChange={handleChange}
                        disabled={disabled}
                        className={`w-full border ${disabled ? 'bg-gray-100' : 'bg-white'} border-gray-300 rounded px-3 py-2`}
                      />
                    </div>
                  ))}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Gender --</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Status --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Joining Date</label>
                    <input
                      type="date"
                      name="joiningDate"
                      value={formData.joiningDate}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                    <select
                      name="deptId"
                      value={formData.deptId}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded px-3 py-2"
                    >
                      <option value="">-- Select Department --</option>
                      {departments.map((d) => (
                        <option key={d.deptId} value={d.deptId}>
                          {d.deptName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-4 mt-6">
                  <button
                    onClick={handleCancel}
                    className="bg-gray-400 hover:bg-gray-500 text-white px-5 py-2 rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={submitForm}
                    className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-md"
                  >
                    {editingEmp ? 'Save Changes' : 'Add Employee'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployeeManagement;
