import React, { useState } from 'react'
import {Link} from 'react-router-dom'
import {Bars3Icon, CalendarDaysIcon, HomeIcon, WalletIcon,BuildingOffice2Icon} from '@heroicons/react/24/solid';
import { UserCircleIcon } from '@heroicons/react/16/solid';

const AdminSidebar = () => {
     const [collapsed , setCollapsed] = useState(false);
  return (
     <div className={` h-screen p-4 shadow-md transition-all rounded-lg duration-300 ${collapsed ? 'w-15' : 'w-60'}`}>
      <button
        className="text-gray-600 mb-6"
        onClick={() => setCollapsed(!collapsed)}
      >
     <Bars3Icon className='h-5 w-5' />
      </button>
      <div className="border-t border-gray-300 mb-4"></div>

      <ul className="space-y-6">
        <li>
          <Link to="/admin" className="flex items-center space-x-2 hover:text-blue-600">
            <HomeIcon className='h-5 w-5' />
            {!collapsed && <span>Dashboard</span>}
          </Link>
        </li>
        <li>
          <Link to="/admin/employees" className="flex items-center space-x-2 hover:text-blue-600">
  <UserCircleIcon className='h-5 w-5' />
  {!collapsed && <span>Employees</span>}
</Link>
        </li>
        <li>
          <Link to="/admin/leaves" className="flex items-center space-x-2 hover:text-blue-600">
            <CalendarDaysIcon className='h-5 w-5'/>
            {!collapsed && <span>Leaves</span>}
          </Link>
        </li>
        <li>
          <Link to="/admin/dept" className="flex items-center space-x-2 hover:text-blue-600">
            <BuildingOffice2Icon className='h-5 w-5' />
            {!collapsed && <span>Departments</span>}
          </Link>
        </li>
           <li>
          <Link to="/admin/payroll" className="flex items-center space-x-2 hover:text-blue-600">
            <WalletIcon className='h-5 w-5' />
            {!collapsed && <span>Payroll </span>}
          </Link>
        </li>
      </ul>
    </div>
  )
}

export default AdminSidebar
