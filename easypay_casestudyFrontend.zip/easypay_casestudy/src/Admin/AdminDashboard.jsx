import React, { useEffect } from 'react';
import Navbar from '../components/Navbar';
import AdminSidebar from './AdminSidebar';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAdminStats } from '../redux/adminStatsSlice'; 
import { UserGroupIcon, BuildingOfficeIcon, BanknotesIcon } from '@heroicons/react/24/outline';

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const { totalEmployees, totalDepartments, totalPayrolls, loading, error } = useSelector(
    (state) => state.adminStats
  );

  useEffect(() => {
    dispatch(fetchAdminStats());
  }, [dispatch]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar user={true} />
      <div className="flex flex-1">
        <AdminSidebar />
        <div className="flex-1 p-8 overflow-y-auto">
          <h1 className="text-4xl font-bold text-gray-800 mb-6">Welcome back, Admin </h1>

          {loading ? (
            <p className="text-gray-600 text-lg">Loading stats...</p>
          ) : error ? (
            <p className="text-red-500 font-semibold">Error: {error}</p>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
                <StatCard
                  title="Total Employees"
                  value={totalEmployees}
                  icon={<UserGroupIcon className="h-6 w-6 text-white" />}
                  bg="from-blue-500 to-indigo-600"
                />
                <StatCard
                  title="Departments"
                  value={totalDepartments}
                  icon={<BuildingOfficeIcon className="h-6 w-6 text-white" />}
                  bg="from-purple-500 to-pink-600"
                />
                <StatCard
                  title="Payroll Records"
                  value={totalPayrolls}
                  icon={<BanknotesIcon className="h-6 w-6 text-white" />}
                  bg="from-green-500 to-emerald-600"
                />
              </div>

              <h2 className="text-2xl font-semibold text-gray-700 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                <QuickLink label="Manage Employees" href="/admin/employees" />
                <QuickLink label="Manage Departments" href="/admin/departments" />
                <QuickLink label="Handle Leaves" href="/admin/leaves" />
                <QuickLink label="Payroll Management" href="/admin/payrolls" />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon, bg }) => (
  <div
    className={`bg-gradient-to-r ${bg} text-white p-6 rounded-2xl shadow-lg transform hover:scale-105 transition duration-300 flex justify-between items-center`}
  >
    <div>
      <p className="text-sm opacity-80">{title}</p>
      <p className="text-3xl font-bold mt-1">{value}</p>
    </div>
    <div className="bg-white bg-opacity-20 rounded-full p-3">
      {icon}
    </div>
  </div>
);

const QuickLink = ({ label, href }) => (
  <a
    href={href}
    className="bg-white border border-gray-300 hover:border-blue-500 hover:shadow-md transition duration-200 p-6 rounded-xl text-center text-blue-700 font-semibold text-sm hover:bg-blue-50"
  >
    {label}
  </a>
);

export default AdminDashboard;

