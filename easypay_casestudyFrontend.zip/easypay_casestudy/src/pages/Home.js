import React from 'react';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';

export const Home = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar />
      <main className="flex flex-col items-center justify-center mt-10 px-4">
        <HeroSection />
      </main>
    </div>
  );
};
