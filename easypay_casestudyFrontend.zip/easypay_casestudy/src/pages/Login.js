import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeftIcon } from '@heroicons/react/24/solid';
import axios from 'axios';

const Login = () => {
  const [formData, setFormData] = useState({
    username: "",
    password: ""
  });

  const navigate = useNavigate();

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post("http://localhost:9000/api/auth/login", formData);
      const token = res.data.token;
      const role = res.data.role;

      localStorage.setItem("token", token);
      alert("Login Successful");

      const cleanRole = role?.replace("ROLE_", "").toLowerCase();
      switch (cleanRole) {
        case "admin":
          navigate("/admin");
          break;
        case "manager":
          navigate("/manager");
          break;
        case "employee":
          navigate("/employee");
          break;
        default:
          navigate("/");
      }
    } catch (error) {
      console.error(error);
      alert(error.response?.data?.message || "Login failed. Please check your credentials.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-indigo-100 to-blue-100 flex items-center justify-center px-4 py-8">
      <div className="bg-white rounded-3xl shadow-xl flex max-w-6xl w-full overflow-hidden">
        {/* Back Arrow */}
        <Link
          to="/"
          className="absolute top-6 left-6 flex items-center space-x-2 text-gray-700 hover:text-indigo-600"
          aria-label="Back"
        >
          <ArrowLeftIcon className="h-5 w-5" />
        </Link>

        {/* Login Form */}
        <div className="w-full lg:w-1/2 px-8 py-12 sm:px-12">
          <h2 className="text-3xl font-bold text-center text-indigo-700">Login to EasyPay</h2>
          <p className="text-sm text-gray-500 text-center mt-1">Welcome back! Please enter your credentials.</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
              <label htmlFor="username" className="text-sm font-medium text-gray-700">Username</label>
              <input
                type="text"
                name="username"
                id="username"
                required
                value={formData.username}
                onChange={handleInputChange}
                className="w-full px-4 py-3 mt-1 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent bg-gray-50"
                placeholder="Enter your username"
              />
            </div>

            <div>
              <label htmlFor="password" className="text-sm font-medium text-gray-700">Password</label>
              <input
                type="password"
                name="password"
                id="password"
                required
                value={formData.password}
                onChange={handleInputChange}
                className="w-full px-4 py-3 mt-1 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:border-transparent bg-gray-50"
                placeholder="Enter your password"
              />
            </div>

            <button
              type="submit"
              className="w-full flex justify-center items-center space-x-2 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition duration-300"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"
                strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
                <circle cx="8.5" cy="7" r="4" />
              </svg>
              <span>Login</span>
            </button>

            <div className="flex justify-between text-sm mt-3 text-gray-600">
              <Link to="#" className="hover:text-indigo-600">Forgot password?</Link>
              <span>
                Don't have an account?
                <Link to="/signup" className="ml-1 text-indigo-600 hover:underline">Sign up</Link>
              </span>
            </div>
          </form>
        </div>

        {/* Image Panel */}
        <div className="hidden lg:flex w-1/2 bg-indigo-50 items-center justify-center p-8">
          <img
            src="https://storage.googleapis.com/devitary-image-host.appspot.com/15848031292911696601-undraw_designer_life_w96d.svg"
            alt="Login Illustration"
            className="w-4/5"
          />
        </div>
      </div>
    </div>
  );
};

export default Login;
