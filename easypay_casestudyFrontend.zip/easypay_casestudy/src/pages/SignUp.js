import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeftIcon } from '@heroicons/react/24/solid';
import axios from 'axios';

const SignUp = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    username: "",
    password: "",
    role: "ADMIN",
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("http://localhost:9000/api/auth/signup", formData)
      .then((res) => {
        alert("Signup Successful!");
        navigate("/login");
      })
      .catch((error) => {
        const message = error?.response?.data?.message || "Signup Failed, try again later";
        alert(message);
        console.error("Signup error:", error);
      });
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-indigo-100 to-blue-100 flex items-center justify-center px-4 py-8">
      <div className="bg-white rounded-3xl shadow-xl flex max-w-6xl w-full overflow-hidden">
        
        {/* Back button */}
        <Link to='/' className='absolute top-6 left-6 hover:text-indigo-600 text-gray-600'>
          <ArrowLeftIcon className='h-5 w-5' />
        </Link>

        {/* Sign Up Form */}
        <div className="w-full lg:w-1/2 px-8 py-12 sm:px-12">
          <h2 className="text-3xl font-bold text-center text-indigo-700">Create your EasyPay account</h2>
          <p className="text-sm text-gray-500 text-center mt-1">Let's get you started!</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div>
              <label htmlFor="username" className="text-sm font-medium text-gray-700">Username</label>
              <input
                type="text"
                name="username"
                id="username"
                value={formData.username}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 mt-1 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 bg-gray-50"
                placeholder="Enter username"
              />
            </div>

            <div>
              <label htmlFor="password" className="text-sm font-medium text-gray-700">Password</label>
              <input
                type="password"
                name="password"
                id="password"
                value={formData.password}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 mt-1 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400 bg-gray-50"
                placeholder="Enter password"
              />
            </div>

            <div>
              <label htmlFor="role" className="text-sm font-medium text-gray-700">Select Role</label>
              <select
                name="role"
                id="role"
                value={formData.role}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 mt-1 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              >
                <option value="ADMIN">Admin</option>
                <option value="MANAGER">Manager</option>
                <option value="EMPLOYEE">Employee</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center items-center space-x-2 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition duration-300"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2"
                strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
                <circle cx="8.5" cy="7" r="4" />
                <path d="M20 8v6M23 11h-6" />
              </svg>
              <span>Sign Up</span>
            </button>

            <div className="text-sm text-center text-gray-600">
              Already have an account?
              <Link to="/login" className="ml-1 text-indigo-600 hover:underline">Log in</Link>
            </div>

            <p className="text-xs text-center text-gray-500">
              By signing up, you agree to our
              <Link to="/terms-of-service" className="text-indigo-600 ml-1 hover:underline">Terms of Service</Link>
              and
              <Link to="/about" className="text-indigo-600 ml-1 hover:underline">Privacy Policy</Link>.
            </p>
          </form>
        </div>

        {/* Image Section */}
        <div className="hidden lg:flex w-1/2 bg-indigo-50 items-center justify-center p-8">
          <img
            src="https://storage.googleapis.com/devitary-image-host.appspot.com/15848031292911696601-undraw_designer_life_w96d.svg"
            alt="Sign Up Illustration"
            className="w-4/5"
          />
        </div>
      </div>
    </div>
  );
};

export default SignUp;
